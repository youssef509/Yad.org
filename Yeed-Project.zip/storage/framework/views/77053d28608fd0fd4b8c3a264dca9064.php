<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>
        <?php echo $__env->yieldContent('title'); ?>
    </title>
    <!-- favicons Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('frontend-assets/images/favicons/apple-touch-icon.png')); ?>" />
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('frontend-assets/images/favicons/favicon-32x32.png')); ?>" />
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('frontend-assets/images/favicons/favicon-16x16.png')); ?>" />
    <link rel="manifest" href="<?php echo e(asset('frontend-assets/images/favicons/site.webmanifest')); ?>" />
    <meta name="description" content="wishon HTML 5 Template " />

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,400;0,500;0,700;1,400;1,500;1,700&display=swap"
        rel="stylesheet">

    <link
        href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/bootstrap/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/animate/animate.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/animate/custom-animate.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/fontawesome/css/all.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/jarallax/jarallax.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/jquery-magnific-popup/jquery.magnific-popup.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/nouislider/nouislider.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/nouislider/nouislider.pips.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/odometer/odometer.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/swiper/swiper.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/wishon-icons/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/tiny-slider/tiny-slider.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/reey-font/stylesheet.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/owl-carousel/owl.carousel.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/owl-carousel/owl.theme.default.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/bxslider/jquery.bxslider.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/bootstrap-select/css/bootstrap-select.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/vegas/vegas.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/jquery-ui/jquery-ui.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/vendors/timepicker/timePicker.css')); ?>" />

    <!-- template styles -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/css/wishon-rtl.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/css/wishon-rtl-custom.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend-assets/css/wishon-responsive-rtl.css')); ?>" />
</head>

<body>



    <div class="preloader">
        <div class="preloader__image"></div>
    </div>
    <!-- /.preloader -->


    <div class="page-wrapper">
        <header class="main-header-four">
            <div class="main-header-four__top">
                <div class="main-header-four__top-wrapper">
                    <div class="container">
                        <div class="main-header-four__top-inner">
                            <div class="main-header-four__top-left">
                                <ul class="list-unstyled main-header-four__contact-list">
                                    <li>
                                        <div class="icon">
                                            <i class="fas fa-envelope-open"></i>
                                        </div>
                                        <div class="text">
                                            <p><a href="needhelp@company.com">needhelp@company.com</a></p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="icon">
                                            <i class="fas fa-mobile"></i>
                                        </div>
                                        <div class="text">
                                            <p><a href="tel:13077760608">+ 1 (307) 776-0608</a></p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="main-header-four__top-right">
                                <ul class="list-unstyled main-header-four__login-reg">
                                    <li><a href="#">Login</a></li>
                                    <li><a href="#">Register</a></li>
                                </ul>
                                <div class="main-header-four__social">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-facebook"></i></a>
                                    <a href="#"><i class="fab fa-pinterest-p"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <nav class="main-menu main-menu-four">
                <div class="main-menu-four__wrapper">
                    <div class="container">
                        <div class="main-menu-four__wrapper-inner">
                            <div class="main-menu-four__left">
                                <div class="main-menu-four__logo">
                                    <a href="index.html"><img src="<?php echo e(asset('frontend-assets/images/resources/logo-4.png')); ?>" alt=""></a>
                                </div>
                            </div>
                            <div class="main-menu-four__right">
                                <div class="main-menu-four__main-menu-box">
                                    <a href="#" class="mobile-nav__toggler"><i class="fa fa-bars"></i></a>
                                    <ul class="main-menu__list">
                                        <li class="dropdown">
                                            <a href="index.html">Home </a>
                                            <ul>
                                                <li><a href="index.html">Home One</a></li>
                                                <li><a href="index2.html">Home Two</a></li>
                                                <li><a href="index3.html">Home Three</a></li>
                                                <li><a href="index4.html">Home Four</a></li>
                                                <li><a href="index-rtl.html#googtrans(en%7Car)">Home RTL</a></li>
                                                <li class="dropdown">
                                                    <a href="#">Header Styles</a>
                                                    <ul>
                                                        <li><a href="index.html">Header One</a></li>
                                                        <li><a href="index2.html">Header Two</a></li>
                                                        <li><a href="index3.html">Header Three</a></li>
                                                        <li><a href="index4.html">Header Four</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class="dropdown">
                                            <a href="#">Pages</a>
                                            <ul>
                                                <li><a href="about.html">About</a></li>
                                                <li><a href="volunteers.html">Volunteers</a></li>
                                                <li><a href="become-volunteer.html">Become A Volunteer</a></li>
                                            </ul>
                                        </li>
                                        <li class="dropdown">
                                            <a href="#">Donations</a>
                                            <ul>
                                                <li><a href="causes.html">Causes</a></li>
                                                <li><a href="cause-details.html">Cause Details</a></li>
                                            </ul>
                                        </li>
                                        <li class="dropdown">
                                            <a href="#">Events</a>
                                            <ul>
                                                <li><a href="events.html">Events</a></li>
                                                <li><a href="event-details.html">Event Details</a></li>
                                            </ul>
                                        </li>
                                        <li class="dropdown">
                                            <a href="#">Blog</a>
                                            <ul>
                                                <li><a href="blog.html">Blog</a></li>
                                                <li><a href="blog-details.html">Blog Details</a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="contact.html">Contact</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="main-menu-four__search-btn-box">
                                    <div class="main-menu-four__search-box">
                                        <a href="#"
                                            class="main-menu-four__search search-toggler icon-magnifying-glass"></a>
                                    </div>
                                    <div class="main-menu-four__btn-box">
                                        <a href="cause-details.html" class="thm-btn main-menu-four__btn">Donate Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </header>

        <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->

<?php /**PATH C:\Users\Youss\OneDrive\Desktop\Yeed-Project\resources\views/frontend/layouts/head.blade.php ENDPATH**/ ?>