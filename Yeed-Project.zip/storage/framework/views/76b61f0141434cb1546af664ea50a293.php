

<?php $__env->startSection('page-content'); ?>
    <h1>Hello,this is just a test</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Youss\OneDrive\Desktop\Yeed-Project\resources\views/backend/test.blade.php ENDPATH**/ ?>