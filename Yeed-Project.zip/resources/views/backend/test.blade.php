@extends('backend.layout')

@section('page-content')
    <h1>Hello,this is just a test</h1>
@endsection